# -*- coding:utf-8 -*-
#@time: 2019/12/31 13:47
#@author: jeremyCheng

import wx
import data
import ui_main

class LoginWindow(wx.Dialog):
    def __init__(self, parent, title):
        wx.Dialog.__init__(self, parent, title=title, size=(800, 600))
        panel = wx.Panel(self, wx.ID_ANY)
        # 创建控件
        labelUserId = wx.StaticText(panel, wx.ID_ANY, '用 户 名:')
        self.inputTextUserId = wx.TextCtrl(panel, wx.ID_ANY, '2017406202')
        lablePasswd = wx.StaticText(panel, wx.ID_ANY, '用户密码:')
        self.inputTextPasswd = wx.TextCtrl(panel, wx.ID_ANY, 'abcd')
        optionalList = ['教务', '教师', '学生']
        self.rboxUserType = wx.RadioBox(panel, label='身份', choices=optionalList)
        self.rboxUserType.SetSelection(2) # 默认学生

        okBtn = wx.Button(panel, wx.ID_ANY, '登录')
        cancelBtn = wx.Button(panel, wx.ID_ANY, '退出')

        topSizer = wx.BoxSizer(wx.VERTICAL)
        userSizer = wx.BoxSizer(wx.HORIZONTAL)
        passwdSizer = wx.BoxSizer(wx.HORIZONTAL)
        userTypeSizer = wx.BoxSizer(wx.HORIZONTAL)
        btnSizer = wx.BoxSizer(wx.HORIZONTAL)

        userSizer.Add(labelUserId, 0, wx.ALL, 5)
        userSizer.Add(self.inputTextUserId, 0, wx.ALL, 5)
        passwdSizer.Add(lablePasswd, 0, wx.ALL, 5)
        passwdSizer.Add(self.inputTextPasswd, 0, wx.ALL, 5)
        userTypeSizer.Add(self.rboxUserType)
        btnSizer.Add(okBtn, 0, wx.ALL, 5)
        btnSizer.Add(cancelBtn, 0, wx.ALL, 5)

        topSizer.Add(userSizer, 0, wx.ALL|wx.CENTER, 5)
        topSizer.Add(passwdSizer, 0, wx.ALL|wx.CENTER, 5)
        topSizer.Add(userTypeSizer, 0, wx.ALL|wx.CENTER, 5)
        topSizer.Add(btnSizer, 0, wx.ALL|wx.CENTER, 5)

        panel.SetSizer(topSizer)  # 全都装进面板里
        topSizer.Fit(self)

        # 绑定事件
        self.Bind(wx.EVT_BUTTON, self.onOk, okBtn)
        self.Bind(wx.EVT_BUTTON, self.onCancel, cancelBtn)


    def onOk(self,e):
        """事件处理函数：登录确认"""
        userId = self.inputTextUserId.GetValue()
        passwd = self.inputTextPasswd.GetValue()
        userType = self.rboxUserType.GetSelection()

        if userId.strip() == None:
            wx.MessageBox("请输入用户名! ")
            self.inputTextUserId.SetFocus()  # This sets the window to receive keyboard input.
            return None
        if passwd.strip() == None:
            wx.MessageBox("请输入登录密码！")
            self.inputTextPasswd.SetFocus()
            return None

        # 验证用户
        username = data.check_login(userId, passwd, userType)
        if not username:
            wx.MessageBox("用户名或密码错误或身份错误， 请重新输入！")
            self.inputTextUserId.SetFocus()
        else:
            self.Close(True) # 关闭窗口
            title = "教务管理系统v1.0 欢迎{0}！".format(username)
            mainFrame = ui_main.MainWindow(None, title, userId, username, userType)
            mainFrame.Show() # 显示教务系统主窗口
            mainFrame.Center()



    def onCancel(self, e):
        self.Close()



if __name__ == '__main__':
    login = LoginWindow(None, '教务系统')
