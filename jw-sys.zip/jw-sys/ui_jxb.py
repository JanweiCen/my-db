# -*- coding:utf-8 -*-
#@time: 2020/1/13 22:04
#@author: jeremyCheng

import wx,data

class JXBWindow(wx.Dialog):
    def __init__(self, parent, title):
        wx.Frame.__init__(self, parent, title=title, size=(800, 600))
        panel = wx.Panel(self, wx.ID_ANY)

        # 创建控件
        optionalAction = ['插入','修改','删除']
        self.rboxAction = wx.RadioBox(panel, label='操作', choices=optionalAction)

        self.listJXB = wx.ListCtrl(panel, wx.ID_ANY, size=(450, 400), style=wx.LC_REPORT)
        self.listJXB.InsertColumn(0, '教学班号', width=50)
        self.listJXB.InsertColumn(1, '课程ID', width=50)
        self.listJXB.InsertColumn(2, '课程名称', width=100)
        self.listJXB.InsertColumn(3, '教师ID', width=50)
        self.listJXB.InsertColumn(4, '教师姓名', width=100)
        self.listJXB.InsertColumn(5, '时间地点', width=100)

        lableJxbId = wx.StaticText(panel, wx.ID_ANY, '教学班号：')
        self.inputJxbId = wx.TextCtrl(panel, wx.ID_ANY, '')
        labelCouseId = wx.StaticText(panel, wx.ID_ANY, '课程  I D：')
        self.inputCourseID = wx.TextCtrl(panel, wx.ID_ANY, '', style=wx.TE_PROCESS_ENTER)
        # labelCourseName = wx.StaticText(panel, wx.ID_ANY, '')
        self.inputCourseName = wx.TextCtrl(panel, wx.ID_ANY, '')
        self.inputCourseName.Disable()
        labelUserId = wx.StaticText(panel, wx.ID_ANY, '教师  I D：')
        self.inputUserId = wx.TextCtrl(panel, wx.ID_ANY, '', style=wx.TE_PROCESS_ENTER)
        # lableUserName = wx.StaticText(panel, wx.ID_ANY, '教师姓名：')
        self.inputUserName = wx.TextCtrl(panel, wx.ID_ANY, '', pos=(683,188))
        self.inputUserName.Disable()
        labelDesc = wx.StaticText(panel, wx.ID_ANY, '时间地点：')
        self.inputDesc = wx.TextCtrl(panel, wx.ID_ANY, '')

        self.insertBtn = wx.Button(panel, wx.ID_ANY, '插入')
        self.updateBtn = wx.Button(panel, wx.ID_ANY, '更新')
        self.updateBtn.Disable()
        self.deleteBtn = wx.Button(panel, wx.ID_ANY, '删除')
        self.deleteBtn.Disable()
        exitBtn = wx.Button(panel, wx.ID_ANY, '退出')

        topSizer = wx.BoxSizer(wx.VERTICAL)
        optionSizer = wx.BoxSizer(wx.HORIZONTAL)
        contentSizer = wx.BoxSizer(wx.HORIZONTAL)
        listSizer = wx.BoxSizer(wx.HORIZONTAL)
        editSizer = wx.BoxSizer(wx.VERTICAL)
        jxbSizer = wx.BoxSizer(wx.HORIZONTAL)
        courseSizer = wx.BoxSizer(wx.HORIZONTAL)
        userSizer = wx.BoxSizer(wx.HORIZONTAL)
        descSizer = wx.BoxSizer(wx.HORIZONTAL)
        btnSizer = wx.BoxSizer(wx.HORIZONTAL)

        optionSizer.Add(self.rboxAction, 0, wx.ALL, 5)

        listSizer.Add(self.listJXB, 0, wx.ALL, 5)

        jxbSizer.Add(lableJxbId, 0, wx.ALL, 5)
        jxbSizer.Add(self.inputJxbId, 0, wx.ALL, 5)
        courseSizer.Add(labelCouseId, 0, wx.ALL, 5)
        courseSizer.Add(self.inputCourseID, 0, wx.ALL, 5)
        courseSizer.Add(self.inputCourseName, 0, wx.ALL, 5)
        
        userSizer.Add(labelUserId, 0, wx.ALL, 5)
        userSizer.Add(self.inputUserId, 0, wx.ALL, 5)
        # userSizer.Add(self.inputUserName, 0, wx.ALL, 5)
        
        descSizer.Add(labelDesc, 0, wx.ALL, 5)
        descSizer.Add(self.inputDesc, 0, wx.ALL, 5)
        btnSizer.Add(self.insertBtn, 0, wx.ALL, 5)
        btnSizer.Add(self.updateBtn, 0, wx.ALL, 5)
        btnSizer.Add(self.deleteBtn, 0, wx.ALL, 5)
        btnSizer.Add(exitBtn, 0, wx.ALL, 5)

        editSizer.Add(jxbSizer, 0, wx.ALL, 5)
        editSizer.Add(courseSizer, 0, wx.ALL, 5)
        editSizer.Add(userSizer, 0, wx.ALL, 5)
        editSizer.Add(descSizer, 0, wx.ALL, 5)
        editSizer.Add(btnSizer, 0, wx.ALL, 5)

        contentSizer.Add(listSizer, 0, wx.ALL, 5)
        contentSizer.Add(editSizer, 0, wx.ALL, 5)
        topSizer.Add(optionSizer, 0, wx.ALL | wx.CENTER, 5)
        topSizer.Add(contentSizer, 0, wx.ALL | wx.CENTER, 5)

        panel.SetSizer(topSizer)
        topSizer.Fit(self)

        self.Bind(wx.EVT_RADIOBOX, self.onAction, self.rboxAction)
        self.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.onJXBList, self.listJXB)
        self.Bind(wx.EVT_TEXT_ENTER, self.onCourseId, self.inputCourseID)
        self.Bind(wx.EVT_TEXT_ENTER, self.onUserId, self.inputUserId)
        self.Bind(wx.EVT_BUTTON, self.onInsert, self.insertBtn)
        self.Bind(wx.EVT_BUTTON, self.onUpdate, self.updateBtn)
        self.Bind(wx.EVT_BUTTON, self.onDelete, self.deleteBtn)
        self.Bind(wx.EVT_BUTTON, self.onExit, exitBtn)

        # 查询用户信息并显示
        self.populate_course_list()

    def populate_course_list(self):

        jxb_list = data.get_jxb_list()
        self.listJXB.DeleteAllItems()
        index = 0
        for jxb in jxb_list:
            print(jxb)
            self.listJXB.InsertItem(index, jxb[0])
            self.listJXB.SetItem(index, 1, jxb[1])
            self.listJXB.SetItem(index, 2, str(jxb[2]))
            self.listJXB.SetItem(index, 3, jxb[3])
            self.listJXB.SetItem(index, 4, jxb[4])
            self.listJXB.SetItem(index, 5, jxb[5])
            index += 1

    def onAction(self, e):
        action = self.rboxAction.GetStringSelection()
        if action == '插入':
            self.inputJxbId.Enable()
            self.insertBtn.Enable()
            self.updateBtn.Disable()
            self.deleteBtn.Disable()
        elif action == '修改':
            self.inputJxbId.Disable()
            self.insertBtn.Disable()
            self.updateBtn.Enable()
            self.deleteBtn.Disable()
        elif action == '删除':
            self.inputJxbId.Disable()
            self.insertBtn.Disable()
            self.updateBtn.Disable()
            self.deleteBtn.Enable()

    def onJXBList(self, e):
        '''在列表中选择用户，内容显示在右边'''
        index = e.GetIndex()
        self.inputJxbId.SetValue(self.listJXB.GetItem(index, 0).GetText())
        self.inputCourseID.SetValue(self.listJXB.GetItem(index, 1).GetText())
        self.inputCourseName.SetValue(self.listJXB.GetItem(index, 2).GetText())
        self.inputUserId.SetValue(self.listJXB.GetItem(index, 3).GetText())
        self.inputUserName.SetValue(self.listJXB.GetItem(index, 4).GetText())
        self.inputDesc.SetValue(self.listJXB.GetItem(index, 5).GetText())

    def onCourseId(self, e):

        courseId = self.inputCourseID.GetValue()

        if len(courseId.strip()) == 0:
            return None
        courseName = data.check_courseId(courseId)
        if courseName:
            self.inputCourseName.SetValue(courseName)
        else:
            wx.MessageBox("该课程不存在！")
            self.inputCourseID
            return None


    def onUserId(self):
        userId = self.inputUserId.GetValue()
        if len(userId.strip()) ==0:
            return None
        username = data.check_userId(userId)
        if username:
            self.inputUserName.SetValue(username)
        else:
            wx.MessageBox("该教师不存在！")
            self.inputUserId.SetFocus()
            return None

    def onInsert(self, e):
        """插入一条数据"""
        jxbid = self.inputJxbId.GetValue()
        courseId = self.inputCourseID.GetValue()
        userid = self.inputUserId.GetValue()
        desc = self.inputDesc.GetValue()

        if len(jxbid.strip()) == 0:
            wx.MessageBox("请输入教学班号！")
            self.inputJxbId.SetFocus()
            return None

        if len(courseId.strip()) == 0:
            wx.MessageBox("请输入课程ID！")
            self.inputCourseID.SetFocus()
            return None

        if len(userid.strip()) == 0:
            wx.MessageBox("请输入教师id！")
            self.inputUserName.SetFocus()
            return None

        if data.check_jxbId(jxbid):
            wx.MessageBox("该教学班已经存在！")
            self.inputJxbId.SetFocus()
            return None

        if not data.check_courseId(courseId):
            wx.MessageBox("该kc不存在！")
            self.inputCourseID.SetFocus()
            return None

        if not data.check_userId(userid):
            wx.MessageBox("该教师不存在！")
            self.inputUserId.SetFocus()
            return None

        # 插入记录
        data.insert_jxb(jxbid, courseId, userid, desc)
        self.refresh_screen()

    def refresh_screen(self):
        """重新刷新新界面"""
        self.inputJxbId.SetValue('')
        self.inputCourseID.SetValue('')
        self.inputCourseName.SetValue('')
        self.inputUserId.SetValue('')
        self.inputUserName.SetValue('')
        self.inputDesc.SetValue('')

        self.populate_course_list()


    def onUpdate(self, e):
        jxbid = self.inputJxbId.GetValue()
        courseid = self.inputCourseID.GetValue()
        userId = self.inputUserId.GetValue()
        desc = self.inputDesc.GetValue()

        if len(courseid.strip()) == 0:
            wx.MessageBox("请输入课程ID！")
            self.inputCourseName.SetFocus()
            return None

        if len(userId.strip()) == 0:
            wx.MessageBox("请输入教师ID！")
            self.inputCourseName.SetFocus()
            return None

        if not data.check_courseId(courseid):
            wx.MessageBox("该课程不存在！")
            self.inputUserId.SetFocus()
            return None

        if not data.check_userId(userId):
            wx.MessageBox("该教师不存在！")
            self.inputUserId.SetFocus()
            return None

        data.update_jxb(jxbid, courseid, userId, desc)
        self.refresh_screen()

    def onDelete(self, e):
        jxbid = self.inputJxbId.GetValue()
        data.delete_jxb(jxbid)
        self.refresh_screen()

    def onExit(self, e):
        self.Close(True)
