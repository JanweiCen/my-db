# -*- coding:utf-8 -*-
#@time: 2020/1/3 21:38
#@author: jeremyCheng

import wx,data

class CourseWindow(wx.Dialog):
    def __init__(self, parent, title):
        wx.Frame.__init__(self, parent, title=title, size=(800, 600))
        panel = wx.Panel(self, wx.ID_ANY)

        # 创建控件
        optionalAction = ['插入','修改','删除']
        self.rboxAction = wx.RadioBox(panel, label='操作', choices=optionalAction)

        self.listCourse = wx.ListCtrl(panel, wx.ID_ANY, size=(400, 400), style=wx.LC_REPORT)
        self.listCourse.InsertColumn(0, '课程ID', width=50)
        self.listCourse.InsertColumn(1, '课程名称', width=100)
        self.listCourse.InsertColumn(2, '学分', width=50)
        self.listCourse.InsertColumn(3, '说明', width=200)

        lableCourseId = wx.StaticText(panel, wx.ID_ANY, '课程  ID：')
        self.inputCourseId = wx.TextCtrl(panel, wx.ID_ANY, '')
        labelCourseName = wx.StaticText(panel, wx.ID_ANY, '课程名称：')
        self.inputCourseName = wx.TextCtrl(panel, wx.ID_ANY, '')
        labelCredit = wx.StaticText(panel, wx.ID_ANY, '课程学分：')
        self.inputCredit = wx.TextCtrl(panel, wx.ID_ANY, '')
        labelDesc = wx.StaticText(panel, wx.ID_ANY, '课程说明：')
        self.inputDesc = wx.TextCtrl(panel, wx.ID_ANY, '')

        self.insertBtn = wx.Button(panel, wx.ID_ANY, '插入')
        self.updateBtn = wx.Button(panel, wx.ID_ANY, '更新')
        self.updateBtn.Disable()
        self.deleteBtn = wx.Button(panel, wx.ID_ANY, '删除')
        self.deleteBtn.Disable()
        exitBtn = wx.Button(panel, wx.ID_ANY, '退出')

        topSizer = wx.BoxSizer(wx.VERTICAL)
        optionSizer = wx.BoxSizer(wx.HORIZONTAL)
        contentSizer = wx.BoxSizer(wx.HORIZONTAL)
        listSizer = wx.BoxSizer(wx.HORIZONTAL)
        editSizer = wx.BoxSizer(wx.VERTICAL)
        courseIdSizer = wx.BoxSizer(wx.HORIZONTAL)
        courseNameSizer = wx.BoxSizer(wx.HORIZONTAL)
        creditSizer = wx.BoxSizer(wx.HORIZONTAL)
        descSizer = wx.BoxSizer(wx.HORIZONTAL)
        btnSizer = wx.BoxSizer(wx.HORIZONTAL)

        optionSizer.Add(self.rboxAction, 0, wx.ALL, 5)

        listSizer.Add(self.listCourse, 0, wx.ALL, 5)

        courseIdSizer.Add(lableCourseId, 0, wx.ALL, 5)
        courseIdSizer.Add(self.inputCourseId, 0, wx.ALL, 5)
        courseNameSizer.Add(labelCourseName, 0, wx.ALL, 5)
        courseNameSizer.Add(self.inputCourseName, 0, wx.ALL, 5)
        creditSizer.Add(labelCredit, 0, wx.ALL, 5)
        creditSizer.Add(self.inputCredit, 0, wx.ALL, 5)
        descSizer.Add(labelDesc, 0, wx.ALL, 5)
        descSizer.Add(self.inputDesc, 0, wx.ALL, 5)
        btnSizer.Add(self.insertBtn, 0, wx.ALL, 5)
        btnSizer.Add(self.updateBtn, 0, wx.ALL, 5)
        btnSizer.Add(self.deleteBtn, 0, wx.ALL, 5)
        btnSizer.Add(exitBtn, 0, wx.ALL, 5)

        editSizer.Add(courseIdSizer, 0, wx.ALL, 5)
        editSizer.Add(courseNameSizer, 0, wx.ALL, 5)
        editSizer.Add(creditSizer, 0, wx.ALL, 5)
        editSizer.Add(descSizer, 0, wx.ALL, 5)
        editSizer.Add(btnSizer, 0, wx.ALL, 5)

        contentSizer.Add(listSizer, 0, wx.ALL, 5)
        contentSizer.Add(editSizer, 0, wx.ALL, 5)
        topSizer.Add(optionSizer, 0, wx.ALL | wx.CENTER, 5)
        topSizer.Add(contentSizer, 0, wx.ALL | wx.CENTER, 5)

        panel.SetSizer(topSizer)
        topSizer.Fit(self)

        self.Bind(wx.EVT_RADIOBOX, self.onAction, self.rboxAction)
        self.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.onCourseList, self.listCourse)
        self.Bind(wx.EVT_BUTTON, self.onInsert, self.insertBtn)
        self.Bind(wx.EVT_BUTTON, self.onUpdate, self.updateBtn)
        self.Bind(wx.EVT_BUTTON, self.onDelete, self.deleteBtn)
        self.Bind(wx.EVT_BUTTON, self.onExit, exitBtn)

        # 查询用户信息并显示
        self.populate_course_list()

    def populate_course_list(self):

        course_list = data.get_course_list()
        self.listCourse.DeleteAllItems()
        index = 0
        for course in course_list:
            print(course)
            self.listCourse.InsertItem(index, course[0])
            self.listCourse.SetItem(index, 1, course[1])
            self.listCourse.SetItem(index, 2, str(course[2]))
            self.listCourse.SetItem(index, 3, course[3])
            index += 1

    def onAction(self, e):
        action = self.rboxAction.GetStringSelection()
        if action == '插入':
            self.inputCourseId.Enable()
            self.insertBtn.Enable()
            self.updateBtn.Disable()
            self.deleteBtn.Disable()
        elif action == '修改':
            self.inputCourseId.Disable()
            self.insertBtn.Disable()
            self.updateBtn.Enable()
            self.deleteBtn.Disable()
        elif action == '删除':
            self.inputCourseId.Disable()
            self.insertBtn.Disable()
            self.updateBtn.Disable()
            self.deleteBtn.Enable()

    def onCourseList(self, e):
        '''在列表中选择用户，内容显示在右边'''
        index = e.GetIndex()
        self.inputCourseId.SetValue(self.listCourse.GetItem(index, 0).GetText())
        self.inputCourseName.SetValue(self.listCourse.GetItem(index, 1).GetText())
        self.inputCredit.SetValue(self.listCourse.GetItem(index, 2).GetText())
        self.inputDesc.SetValue(self.listCourse.GetItem(index, 3).GetText())

    def onInsert(self, e):
        """插入一条数据"""
        courseId = self.inputCourseId.GetValue()
        courseName = self.inputCourseName.GetValue()
        credit = self.inputCredit.GetValue()
        desc = self.inputDesc.GetValue()

        if len(courseId.strip()) == 0:
            wx.MessageBox("请输入课程ID！")
            self.inputCourseId.SetFocus()
            return None
        if len(courseName.strip()) == 0:
            wx.MessageBox("请输入课程名称！")
            self.inputCourseName.SetFocus()
            return None
        if data.check_courseId(courseId):
            wx.MessageBox("该kc已存在！")
            self.inputCourseId.SetFocus()
            return None
        # 插入记录
        data.insert_course(courseId, courseName, credit, desc)
        self.refresh_screen()

    def refresh_screen(self):
        """重新刷新新界面"""
        self.inputCourseId.SetValue('')
        self.inputCourseName.SetValue('')
        self.inputCredit.SetValue('')
        self.inputDesc.SetValue('')
        self.populate_course_list()

    def onUpdate(self, e):
        courseid = self.inputCourseId.GetValue()
        username = self.inputCourseName.GetValue()
        birthday = self.inputCredit.GetValue()
        department = self.inputDesc.GetValue()

        if len(username.strip()) == 0:
            wx.MessageBox("请输入课程名称！")
            self.inputCourseName.SetFocus()
            return None
        data.update_course(courseid, username, birthday, department)
        self.refresh_screen()

    def onDelete(self, e):
        courseid = self.inputCourseId.GetValue()
        data.delete_course(courseid)
        self.refresh_screen()

    def onExit(self, e):
        self.Close(True)
