# -*- coding:utf-8 -*-
#@time: 2020/2/1 14:12
#@author: jeremyCheng

import wx
import ui_login

class App(wx.App):
    def OnInit(self):
        frame = ui_login.LoginWindow(parent=None, title="Sign in")
        frame.Show()
        frame.Center()
        return True


if __name__ == '__main__':
    app = App()
    app.MainLoop()