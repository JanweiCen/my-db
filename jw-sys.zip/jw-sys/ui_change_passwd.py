# -*- coding:utf-8 -*-
#@time: 2019/12/31 16:17
#@author: jeremyCheng

import wx
import data
import ui_main



class ChangePasswdWindow(wx.Dialog):
    def __init__(self, parent, title, userID):
        wx.Dialog.__init__(self, parent, title=title, size=(800, 600))
        self.userId=userID

        panel = wx.Panel(self, wx.ID_ANY)

        labelPasswd_old = wx.StaticText(panel, wx.ID_ANY, '输入新密码')
        self.inputTextPwdOld = wx.TextCtrl(panel, wx.ID_ANY, '12324')
        labelPasswd_new = wx.StaticText(panel, wx.ID_ANY, '确认新密码')
        self.inputTextPwdNew = wx.TextCtrl(panel, wx.ID_ANY, 'abcjd')

        okBtn = wx.Button(panel, wx.ID_ANY, '确定')
        cancelBtn = wx.Button(panel, wx.ID_ANY, '取消')

        topSizer = wx.BoxSizer(wx.VERTICAL)
        passwd_old_sizer = wx.BoxSizer(wx.HORIZONTAL)
        passwd_new_sizer = wx.BoxSizer(wx.HORIZONTAL)
        btnSizer = wx.BoxSizer(wx.HORIZONTAL)

        passwd_old_sizer.Add(labelPasswd_old, 0, wx.ALL, 5)
        passwd_old_sizer.Add(self.inputTextPwdOld, 0, wx.ALL, 5)
        passwd_new_sizer.Add(labelPasswd_new, 0, wx.ALL, 5)
        passwd_new_sizer.Add(self.inputTextPwdNew, 0, wx.ALL, 5)
        btnSizer.Add(okBtn, 0, wx.ALL, 5)
        btnSizer.Add(cancelBtn, 0, wx.ALL, 5)

        topSizer.Add(passwd_old_sizer, 0, wx.ALL|wx.CENTER, 5)
        topSizer.Add(passwd_new_sizer, 0, wx.ALL|wx.CENTER, 5)
        topSizer.Add(btnSizer, 0, wx.ALL|wx.CENTER, 5)

        panel.SetSizer(topSizer)
        topSizer.Fit(self)

        self.Bind(wx.EVT_BUTTON, self.onOk, okBtn)
        self.Bind(wx.EVT_BUTTON, self.onCancle, cancelBtn)

    def onOk(self, e):
        old_passwd = self.inputTextPwdOld.GetValue()
        new_passwd = self.inputTextPwdNew.GetValue()
        if len(old_passwd.strip()) == 0:
            wx.MessageBox("请重新输入！")
            self.inputTextPwdOld.SetFocus()
            return None
        if old_passwd != new_passwd:
            wx.MessageBox("两次输入的密码不一致")
            self.inputTextPwdNew.SetFocus()
            return None



        data.change_passwd(self.userId, old_passwd)
        self.Close()

    def onCancle(self, e):
        self.Close(True)





