# -*- coding:utf-8 -*-
#@time: 2019/12/31 16:49
#@author: jeremyCheng

import data, wx

class UserWindow(wx.Dialog):
    def __init__(self, parent, title):
        wx.Frame.__init__(self, parent, title=title, size=(800, 600))
        panel = wx.Panel(self, wx.ID_ANY)

        optionalAction = ['插入','修改','删除']
        self.rboxAction = wx.RadioBox(panel, label='操作', choices=optionalAction)
        optionalType = ['学生','教师','教务']
        self.rboxUserType = wx.RadioBox(panel, label='身份', choices=optionalType)

        self.listUser = wx.ListCtrl(panel, wx.ID_ANY, size=(450, 380), style=wx.LC_REPORT)
        self.listUser.InsertColumn(0, '用户ID', width=80)
        self.listUser.InsertColumn(1, '姓  名', width=50)
        self.listUser.InsertColumn(2, '性  别', width=50)
        self.listUser.InsertColumn(3, '出生日期', width=80)
        self.listUser.InsertColumn(4, '院  系', width=50)
        self.listUser.InsertColumn(5, '电  话', width=100)


        labelUserId = wx.StaticText(panel, wx.ID_ANY, '用户  ID：')
        self.inputTextUserId = wx.TextCtrl(panel, wx.ID_ANY,'', style=2, pos=(550,95))
        labelUserName = wx.StaticText(panel, wx.ID_ANY, '用户姓名:')
        self.inputTextUserName = wx.TextCtrl(panel, wx.ID_ANY, '', style=0)
        labelBirthDay = wx.StaticText(panel, wx.ID_ANY, '出生日期:')
        self.inputTextBirthday = wx.TextCtrl(panel, wx.ID_ANY, '')

        labelDepartment = wx.StaticText(panel, wx.ID_ANY, '所属院系:')
        self.inputTextDepartment = wx.TextCtrl(panel, wx.ID_ANY, '')

        labelPhone = wx.StaticText(panel, wx.ID_ANY, '电话号码:')
        self.inputTextPhone = wx.TextCtrl(panel, wx.ID_ANY, '')
        optionalGender = ['男','女']
        self.rboxGender = wx.RadioBox(panel, label='性 别', choices=optionalGender)

        self.insertBtn = wx.Button(panel, wx.ID_ANY, '插入')
        self.updateBtn = wx.Button(panel, wx.ID_ANY, '更新')
        self.updateBtn.Disable()
        self.deleteBtn = wx.Button(panel, wx.ID_ANY, '删除')
        self.deleteBtn.Disable()
        exitBtn = wx.Button(panel, wx.ID_ANY, '退出')

        topSizer = wx.BoxSizer(wx.VERTICAL)
        optionSizer = wx.BoxSizer(wx.HORIZONTAL)
        contentSizer = wx.BoxSizer(wx.HORIZONTAL)
        listSizer = wx.BoxSizer(wx.HORIZONTAL)
        editSizer = wx.BoxSizer(wx.VERTICAL)
        userIdSizer = wx.BoxSizer(wx.HORIZONTAL)
        usernameSizer = wx.BoxSizer(wx.HORIZONTAL)
        birthdaySizer = wx.BoxSizer(wx.HORIZONTAL)
        departmentSizer = wx.BoxSizer(wx.HORIZONTAL)
        phoneSizer = wx.BoxSizer(wx.HORIZONTAL)
        genderSizer = wx.BoxSizer(wx.HORIZONTAL)
        btnSizer = wx.BoxSizer(wx.HORIZONTAL)

        optionSizer.Add(self.rboxAction, 0, wx.ALL, 5)
        optionSizer.Add(self.rboxUserType, 0, wx.ALL, 5)

        listSizer.Add(self.listUser, 0, wx.ALL, 5)
        userIdSizer.Add(labelUserId, 0, wx.ALL, 5)
        usernameSizer.Add(labelUserName, 0, wx.ALL, 5)
        usernameSizer.Add(self.inputTextUserName, 0, wx.ALL, 5)
        birthdaySizer.Add(labelBirthDay, 0, wx.ALL, 5)
        birthdaySizer.Add(self.inputTextBirthday, 0, wx.ALL, 5)
        departmentSizer.Add(labelDepartment, 0, wx.ALL, 5)
        departmentSizer.Add(self.inputTextDepartment, 0, wx.ALL, 5)
        phoneSizer.Add(labelPhone, 0, wx.ALL, 5)
        phoneSizer.Add(self.inputTextPhone, 0, wx.ALL, 5)
        genderSizer.Add(self.rboxGender, 0, wx.ALL, 5)
        btnSizer.Add(self.insertBtn, 0, wx.ALL, 5)
        btnSizer.Add(self.updateBtn, 0, wx.ALL, 5)
        btnSizer.Add(self.deleteBtn, 0, wx.ALL, 5)
        btnSizer.Add(exitBtn, 0, wx.ALL, 5)

        editSizer.Add(userIdSizer, 0, wx.ALL, 5)
        editSizer.Add(usernameSizer, 0, wx.ALL, 5)
        editSizer.Add(birthdaySizer, 0, wx.ALL, 5)
        editSizer.Add(departmentSizer, 0, wx.ALL, 5)
        editSizer.Add(phoneSizer, 0, wx.ALL, 5)
        editSizer.Add(genderSizer, 0, wx.ALL, 5)
        editSizer.Add(btnSizer, 0, wx.ALL, 5)

        contentSizer.Add(listSizer, 0, wx.ALL, 5)
        contentSizer.Add(editSizer, 0, wx.ALL, 5)
        topSizer.Add(optionSizer, 0, wx.ALL|wx.CENTER, 5)
        topSizer.Add(contentSizer, 0, wx.ALL|wx.CENTER, 5)

        panel.SetSizer(topSizer)
        topSizer.Fit(self)


        # 绑定事件
        self.Bind(wx.EVT_RADIOBOX, self.onAction, self.rboxAction)
        self.Bind(wx.EVT_RADIOBOX, self.onUserType, self.rboxUserType)
        self.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.onUserList, self.listUser)
        self.Bind(wx.EVT_BUTTON, self.onInsert, self.insertBtn)
        self.Bind(wx.EVT_BUTTON, self.onUpdate, self.updateBtn)
        self.Bind(wx.EVT_BUTTON, self.onDelete, self.deleteBtn)
        self.Bind(wx.EVT_BUTTON, self.onExit, exitBtn)

        # 查询用户信息并显示
        self.populate_user_list()

    def populate_user_list(self):
        userType = self.rboxUserType.GetStringSelection()
        user_list = data.get_user_list(userType)
        self.listUser.DeleteAllItems()
        index = 0
        for user in user_list:
            self.listUser.InsertItem(index, user[0])
            self.listUser.SetItem(index, 1, user[1])
            self.listUser.SetItem(index, 2, user[2])
            self.listUser.SetItem(index, 3, user[3])
            self.listUser.SetItem(index, 4, user[4])
            self.listUser.SetItem(index, 5, user[5])
            index += 1

    def onAction(self, e):
        action = self.rboxAction.GetStringSelection()
        if action == '插入':
            self.rboxUserType.Enable()
            self.inputTextUserId.Enable()
            self.insertBtn.Enable()
            self.updateBtn.Disable()
            self.deleteBtn.Disable()
        elif action == '修改':
            self.rboxUserType.Disable()
            self.inputTextUserId.Disable()
            self.insertBtn.Disable()
            self.updateBtn.Enable()
            self.deleteBtn.Disable()
        elif action == '删除':
            self.rboxUserType.Disable()
            self.inputTextUserId.Disable()
            self.insertBtn.Disable()
            self.updateBtn.Disable()
            self.deleteBtn.Enable()

    def onUserType(self, e):
        '''显示对应类别用户的信息列表'''
        self.populate_user_list()

    def onUserList(self, e):
        '''在列表中选择用户，内容显示在右边'''
        index = e.GetIndex()
        self.inputTextUserId.SetValue(self.listUser.GetItem(index, 0).GetText())
        self.inputTextUserName.SetValue(self.listUser.GetItem(index,1).GetText())
        if self.listUser.GetItem(index, 2).GetText()=='男': n =0
        else:
            n = 1
        self.rboxGender.SetSelection(n)
        self.inputTextBirthday.SetValue(self.listUser.GetItem(index, 3).GetText())
        self.inputTextDepartment.SetValue(self.listUser.GetItem(index, 4).GetText())
        self.inputTextPhone.SetValue(self.listUser.GetItem(index, 5).GetText())


    def onInsert(self, e):
        """插入一条数据"""
        userType = self.rboxUserType.GetStringSelection()
        userId = self.inputTextUserId.GetValue()
        username = self.inputTextUserName.GetValue()
        birthday = self.inputTextBirthday.GetValue()
        department = self.inputTextDepartment.GetValue()
        phone = self.inputTextPhone.GetValue()
        gender = self.rboxGender.GetStringSelection()

        if len(username.strip()) == 0:
            wx.MessageBox("请输入用户名！")
            self.inputTextUserName.SetFocus()
            return None
        if data.check_userId(userId):
            wx.MessageBox("该用户已存在！")
            self.inputTextUserId.SetFocus()
            return None
        # 插入记录
        data.insert_user(userType, userId, username, gender, birthday, department, phone)
        self.refresh_screen()

    def refresh_screen(self):
        """重新刷新新界面"""
        self.inputTextUserId.SetValue('')
        self.inputTextUserName.SetValue('')
        self.inputTextBirthday.SetValue('')
        self.inputTextDepartment.SetValue('')
        self.inputTextPhone.SetValue('')
        self.populate_user_list()

    def onUpdate(self, e):
        userId = self.inputTextUserId.GetValue()
        username = self.inputTextUserName.GetValue()
        birthday = self.inputTextBirthday.GetValue()
        department = self.inputTextDepartment.GetValue()
        phone = self.inputTextPhone.GetValue()
        gender = self.rboxGender.GetStringSelection()

        if len(username.strip()) == 0:
            wx.MessageBox("请输入用户名！")
            self.inputTextUserName.SetFocus()
            return None
        data.update_user(userId, username, gender, birthday, department, phone)
        self.refresh_screen()

    def onDelete(self, e):
        userId = self.inputTextUserId.GetValue()
        data.delete_user(userId)
        self.refresh_screen()

    def onExit(self, e):
        self.Close(True)



