# -*- coding:utf-8 -*-
#@time: 2020/1/13 22:47
#@author: jeremyCheng

import wx,data

class StudentWindow(wx.Dialog):
    def __init__(self, parent, title, userId):
        wx.Frame.__init__(self, parent, title=title, size=(800, 600))
        self.userId = userId
        panel = wx.Panel(self, wx.ID_ANY)

        # 创建控件
        optionalAction = ['选课', '退选']
        self.rboxAction = wx.RadioBox(panel, label='操作', choices=optionalAction)

        self.listGrade = wx.ListCtrl(panel, wx.ID_ANY, size=(550, 400), style=wx.LC_REPORT)
        self.listGrade.InsertColumn(0, '教学班号', width=80)
        self.listGrade.InsertColumn(1, '课程ID', width=50)
        self.listGrade.InsertColumn(2, '课程名称', width=100)
        self.listGrade.InsertColumn(3, '教师ID', width=50)
        self.listGrade.InsertColumn(4, '教师姓名', width=100)
        self.listGrade.InsertColumn(5, '时间地点', width=120)
        self.listGrade.InsertColumn(6, '成绩', width=50)

        lableJxbId = wx.StaticText(panel, wx.ID_ANY, '教学班号:')
        self.inputJxbId = wx.TextCtrl(panel, wx.ID_ANY, '', style=wx.TE_PROCESS_ENTER)

        labelCoursID = wx.StaticText(panel, wx.ID_ABOUT, '课程  I D：')
        self.inputCourseID = wx.TextCtrl(panel, wx.ID_ANY, '',style=wx.TE_PROCESS_ENTER)
        self.inputCourseID.Disable()
        

        self.inputCourseName = wx.TextCtrl(panel, wx.ID_ANY, '',style=wx.TE_PROCESS_ENTER)
        self.inputCourseName.Disable()
        labelUserId = wx.StaticText(panel, wx.ID_ANY, '教师 I D:')
        self.inputUserId = wx.TextCtrl(panel, wx.ID_ANY, '',style=wx.TE_PROCESS_ENTER)
        self.inputUserId.Disable()
        
        # lableUserName = wx.StaticText(panel, wx.ID_ANY, '教师姓名：')
        self.inputUserName = wx.TextCtrl(panel, wx.ID_ANY, '',style=wx.TE_PROCESS_ENTER)
        self.inputUserName.Disable()
        
        labelDesc = wx.StaticText(panel, wx.ID_ANY, '时间地点:')
        self.inputDesc = wx.TextCtrl(panel, wx.ID_ANY, '',style=wx.TE_PROCESS_ENTER)
        self.inputDesc.Disable()
        
        labelScore = wx.StaticText(panel, wx.ID_ANY, '学生成绩:')
        self.inputScore = wx.TextCtrl(panel, wx.ID_ANY,'',style=wx.TE_PROCESS_ENTER)
        self.inputScore.Disable()
        

        self.insertBtn = wx.Button(panel, wx.ID_ANY, '选课')
        self.deleteBtn = wx.Button(panel, wx.ID_ANY, '退选')
        self.deleteBtn.Disable()
        
        exitBtn = wx.Button(panel, wx.ID_ANY, '退出')

        topSizer = wx.BoxSizer(wx.VERTICAL)
        optionSizer = wx.BoxSizer(wx.HORIZONTAL)
        contentSizer = wx.BoxSizer(wx.HORIZONTAL)
        listSizer = wx.BoxSizer(wx.HORIZONTAL)
        editSizer = wx.BoxSizer(wx.VERTICAL)
        jxbSizer = wx.BoxSizer(wx.HORIZONTAL)
        courseSizer = wx.BoxSizer(wx.HORIZONTAL)
        userSizer = wx.BoxSizer(wx.HORIZONTAL)
        descSizer = wx.BoxSizer(wx.HORIZONTAL)
        scoreSizer = wx.BoxSizer(wx.HORIZONTAL)
        btnSizer = wx.BoxSizer(wx.HORIZONTAL)

        optionSizer.Add(self.rboxAction, 0, wx.ALL, 5)

        listSizer.Add(self.listGrade, 0, wx.ALL, 5)

        jxbSizer.Add(lableJxbId, 0, wx.ALL, 5)
        jxbSizer.Add(self.inputJxbId, 0, wx.ALL, 5)
        contentSizer.Add(labelCoursID, 0, wx.ALL, 5)
        courseSizer.Add(self.inputCourseID, 0, wx.ALL, 5)
        courseSizer.Add(self.inputCourseName, 0, wx.ALL, 5)

        userSizer.Add(labelUserId, 0, wx.ALL, 5)
        userSizer.Add(self.inputUserId, 0, wx.ALL, 5)
        userSizer.Add(self.inputUserName, 0, wx.ALL, 5)

        descSizer.Add(labelDesc, 0, wx.ALL, 5)
        descSizer.Add(self.inputDesc, 0, wx.ALL, 5)
        
        scoreSizer.Add(labelScore, 0, wx.ALL, 5)
        scoreSizer.Add(self.inputScore, 0, wx.ALL, 5)
        
        btnSizer.Add(self.insertBtn, 0, wx.ALL, 5)
        btnSizer.Add(self.deleteBtn, 0, wx.ALL, 5)
        btnSizer.Add(exitBtn, 0, wx.ALL, 5)

        editSizer.Add(jxbSizer, 0, wx.ALL, 5)
        editSizer.Add(courseSizer, 0, wx.ALL, 5)
        editSizer.Add(userSizer, 0, wx.ALL, 5)
        editSizer.Add(descSizer, 0, wx.ALL, 5)
        editSizer.Add(scoreSizer, 0, wx.ALL, 5)
        editSizer.Add(btnSizer, 0, wx.ALL, 5)

        contentSizer.Add(listSizer, 0, wx.ALL, 5)
        contentSizer.Add(editSizer, 0, wx.ALL, 5)
        
        topSizer.Add(optionSizer, 0, wx.ALL | wx.CENTER, 5)
        topSizer.Add(contentSizer, 0, wx.ALL | wx.CENTER, 5)

        panel.SetSizer(topSizer)
        topSizer.Fit(self)

        self.Bind(wx.EVT_RADIOBOX, self.onAction, self.rboxAction)
        self.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.onGradeList, self.listGrade)

        self.Bind(wx.EVT_TEXT_ENTER, self.onJxbId, self.inputJxbId)

        self.Bind(wx.EVT_BUTTON, self.onInsert, self.insertBtn)
        self.Bind(wx.EVT_BUTTON, self.onDelete, self.deleteBtn)
        self.Bind(wx.EVT_BUTTON, self.onExit, exitBtn)

        # 查询用户信息并显示
        self.populate_course_list()

    def populate_course_list(self):

        course_list = data.get_grade_list_by_student(self.userId)
        self.listGrade.DeleteAllItems()
        index = 0
        for grade in course_list:
            self.listGrade.InsertItem(index, grade[0])
            self.listGrade.SetItem(index, 1, grade[1])
            self.listGrade.SetItem(index, 2, str(grade[2]))
            self.listGrade.SetItem(index, 3, grade[3])
            self.listGrade.SetItem(index, 4, grade[4])
            self.listGrade.SetItem(index, 5, grade[5])
            self.listGrade.SetItem(index, 6, str(grade[6]))
            index += 1

    def onAction(self, e):
        action = self.rboxAction.GetStringSelection()
        if action == '选课':
            self.inputJxbId.Enable()
            self.insertBtn.Enable()
            self.deleteBtn.Disable()

        elif action == '退选':
            self.inputJxbId.Disable()
            self.insertBtn.Disable()
            self.deleteBtn.Enable()

    def onGradeList(self, e):
        '''在列表中选择courses，内容显示在右边'''
        index = e.GetIndex()
        self.inputJxbId.SetValue(self.listGrade.GetItem(index, 0).GetText())
        self.inputCourseID.SetValue(self.listGrade.GetItem(index, 1).GetText())
        self.inputCourseName.SetValue(self.listGrade.GetItem(index, 2).GetText())
        self.inputUserId.SetValue(self.listGrade.GetItem(index, 3).GetText())
        self.inputUserName.SetValue(self.listGrade.GetItem(index, 4).GetText())
        self.inputDesc.SetValue(self.listGrade.GetItem(index, 5).GetText())
        self.inputScore.SetValue(self.listGrade.GetItem(index, 6).GetText())

    def onJxbId(self, e):
        """插入一条数据"""
        jxbId = self.inputCourseID.GetValue()
        import data
        if len(jxbId.strip()) == 0:
            return None
        if data.check_jxbId(jxbId):
            courseId, couserName, userId, username, desc = data.check_jxbId(jxbId)
            self.inputCourseID.SetValue(courseId)
            self.inputCourseName.SetValue(courseName)
            self.inputUserId.SetValue(userId)
            self.inputUserName.SetValue(username)
            self.inputDesc.SetValue(desc)
        else:
            wx.MessageBox("该课程plan不存在！")
            self.inputCourseID.SetFocus()
            return None
    #
    # def onUserId(self):
    #     userId = self.inputUserId.GetValue()
    #     if len(userId.strip()) == 0:
    #         return None
    #     username = data.check_userId(userId)
    #     if username:
    #         self.inputUserName.SetValue(username)
    #     else:
    #         wx.MessageBox("该教师不存在！")
    #         self.inputUserId.SetFocus()
    #         return None

    def onInsert(self, e):
        """插入一条数据"""
        jxbid = self.inputJxbId.GetValue()
        # courseId = self.inputCourseID.GetValue()
        # userid = self.inputUserId.GetValue()
        # desc = self.inputDesc.GetValue()

        if len(jxbid.strip()) == 0:
            wx.MessageBox("请输入教学班号！")
            self.inputJxbId.SetFocus()
            return None

        if data.check_grade_id(jxbid, self.userId):
            wx.MessageBox("该课已选，不能重复选课！")
            self.inputJxbId.SetFocus()
            return None

        # 插入记录
        data.insert_grade(jxbid, self.userId, None)
        self.refresh_screen()

    def refresh_screen(self):
        """重新刷新新界面"""
        self.inputJxbId.SetValue('')
        self.inputCourseID.SetValue('')
        self.inputCourseName.SetValue('')
        self.inputCourseID.SetValue('')
        self.inputUserId.SetValue('')
        self.inputUserName.SetValue('')
        self.inputDesc.SetValue('')

        self.populate_course_list()
    #
    # def onUpdate(self, e):
    #     jxbid = self.inputJxbId.GetValue()
    #     courseid = self.inputCourseID.GetValue()
    #     userId = self.inputUserId.GetValue()
    #     desc = self.inputDesc.GetValue()
    #
    #     if len(courseid.strp()) == 0:
    #         wx.MessageBox("请输入课程ID！")
    #         self.inputCourseName.SetFocus()
    #         return None
    #
    #     if len(userId.strp()) == 0:
    #         wx.MessageBox("请输入教师ID！")
    #         self.inputCourseName.SetFocus()
    #         return None
    #
    #     if data.check_courseId(courseid):
    #         wx.MessageBox("该课程不存在！")
    #         self.inputUserId.SetFocus()
    #         return None
    #
    #     if not data.check_userId(userid):
    #         wx.MessageBox("该教师不存在！")
    #         self.inputUserId.SetFocus()
    #         return None
    #
    #     data.update_jxb(jxbid, courseid, userId, desc)
    #     self.refresh_screen()

    def onDelete(self, e):
        jxbid = self.inputJxbId.GetValue()
        data.delete_jxb(jxbid)
        self.refresh_screen()

    def onExit(self, e):
        self.Close(True)
