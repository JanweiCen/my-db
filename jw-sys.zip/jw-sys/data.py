# -*- coding:utf-8 -*-
# @time: 2019/12/30 14:05
# @author: jeremyCheng

"""用户管理系统, 基于sqlite"""

import sqlite3
import os

DBFILE = r'E:\data\sqlitedb\jwsys.db'  # sqlite 数据库，全局变量


def get_create_db(db_filename):
    '''打开本地DB文件，返回db连接'''
    if os.path.exists(db_filename):
        con = sqlite3.connect(db_filename)
    else:
        con = sqlite3.connect(db_filename)

        sql_create_UserInfo = """
            create table UserInfo(
                userId varchar(20) primary key,
                userName varchar(20) not null,
                gender varchar(2),
                birthday varchar(11),
                department varchar(50),
                phone varchar(20),
                userType varchar(2),
                password varchar(20) not null 
            );
        """
        # con.execute(sql_create_UserInfo)
        # sql_insert_UserInfo = """insert into UserInfo values
        #     ('J001', '张教务','女', '1988/5/2','数学系','13888333388','教务','123456')"""
        # con.execute(sql_insert_UserInfo)
        # print("插入成功")
        # con.commit()

        # course table
        sql_create_Course = """
            create table Course(
                courseId varchar(20) primary key,
                courseName varchar(20) not null,
                credit int,
                description varchar(100)
            );
        """

        # jxb table
        sql_create_JXB = """
            create table JXB(
                jxbId varchar(20) primary key,
                courseId varchar(20) not null,
                userId varchar(20) not null,
                description varchar(100));
        """

        # grade table
        sql_create_Grades = """
            create table Grades(
                jxbId varchar(20),
                userId varchar(20),
                score int,
                primary key(jxbId, userId)
            );
        """
        # con.execute(sql_create_Course)
        # con.execute(sql_create_JXB)
        # con.execute(sql_create_Grades)
        # con.commit()

    return con


def check_login(userId, password, userType):
    '''检查用户登录信息'''
    # if userType == 0: usertype = '教务'
    # if userType == 1: usertype = "教师"
    # if userType ==2: userTtpe="学生"
    con = get_create_db(DBFILE)
    try:
        sql_pattern = """select userName from UserInfo where userId='{0}' and password='{1}' and userType='{2}'"""
        if userType == 0:
            sql = sql_pattern.format(userId, password, "教务")
        elif userType == 1:
            sql = sql_pattern.format(userId, password, "教师")
        elif userType == 2:
            sql = sql_pattern.format(userId, password, "学生")
        cur = con.execute(sql)
        row = cur.fetchone()
        if row:
            return row[0]  # userName
        else:
            return False
    finally:
        cur.close()
        con.close()


def change_passwd(userId, passwd):
    '''修改用户密码'''
    con = get_create_db(DBFILE)

    try:
        sql_pattern = """
            update UserInfo set password='{0}' where userId='{1}'
        """
        sql = sql_pattern.format(passwd, userId)
        con.execute(sql)
        con.commit()
        print("修改密码成功")

    finally:
        con.close()


##########################用户管理#########################

def check_userId(userId):
    '''检查userInfo表是否有userid'''
    con = get_create_db(DBFILE)

    try:
        sql_partten = """select userId, userName from UserInfo where userId='{0}'"""
        sql = sql_partten.format(userId)
        cur = con.execute(sql)
        row = cur.fetchone()
        if row:
            return row  # 返回userName
        else:
            return False
    finally:
        con.close()


def get_user_list(userType=None):
    '''查找数据库UserInfo表，获取类型为userType的用户列表'''
    con = get_create_db(DBFILE)
    try:
        if userType:
            sql_partten = """
                    select * from UserInfo where userType='{0}'
                """
        else:
            sql_partten = """
                select * from UserInfo"""
        sql = sql_partten.format(userType)
        results = con.execute(sql)
        users = results.fetchall()
        user_list = []
        for user in users:
            user_list.append(user)
        # print(user_list)
        return user_list
    finally:
        con.close()


def insert_user(userType, userId, userName, gender, birthday, department, phone):
    """插入一条记录到UserInfo表"""
    con = get_create_db(DBFILE)
    try:
        sql = """
            insert into UserInfo(userId, userName, gender, birthday, department, phone, userType, password) 
            values(?,?,?,?,?,?,?,?)
        """
        con.execute(sql, (userId, userName, gender, birthday, department, phone, userType, '123456'))
        con.commit()
    finally:
        con.close()

def update_user(userId, userName, gender, birthday, department, phone):
    """更新表UserInfo一条记录"""
    con = get_create_db(DBFILE)
    try:
        sql = """
            update UserInfo set userName=?,
                gender=?,
                birthday=?,
                department=?,
                phone=?
            where userId=?
        """
        con.execute(sql, (userName, gender, birthday, department, phone, userId))
        con.commit()

    finally:
        con.close()

def delete_user(userId):
     """删除一条用户记录"""
     con = get_create_db(DBFILE)
     try:
         sql = "delete from UserInfo where userId=?"
         con.execute(sql, (userId, ))
         con.commit()

     finally:con.close()

##########################课程管理#######################

def check_courseId(courseId):
    """检查Course表是否存在courseId"""
    con = get_create_db(DBFILE)
    try:
        sql = """
            select courseId, courseName from Course where courseId=?
        """
        executed = con.execute(sql, (courseId, ))
        row = executed.fetchone()
        # print(row)
        if row:
            return row[1] #courseName

    finally:
        con.close()

def insert_course(courseId, courseName, credit, desc):
    """插入一条记录到Course表"""
    con = get_create_db(DBFILE)
    try:
        sql = """insert into Course (
            courseId,
            courseName,
            credit,
            description
        )values(?,?,?,?)"""

        con.execute(sql, (courseId, courseName, credit, desc))
        con.commit()

    finally:con.close()

def get_course_list():
    con = get_create_db(DBFILE)
    try:
        sql = """
            select * from Course
        """
        executed = con.execute(sql)
        courses = executed.fetchall()
        course_list = []
        for course in courses:
            course_list.append(course)
        return course_list

    finally: con.close()

def update_course(courseId, courseName, credit, desc):
    con = get_create_db(DBFILE)
    try:
        sql = """
            update Course set 
                courseName=?,
                credit=?,
                description=?
            where courseId=?
        """
        con.execute(sql, (courseName, credit, desc, courseId))
        con.commit()

    finally:con.close()

def delete_course(courseId):
    con = get_create_db(DBFILE)
    try:
        sql = """
            delete from Course where courseId='{0}'
        """
        sql = sql.format(courseId)
        con.execute(sql)

    finally:con.close()


##########################开课计划jxb（教学班）###########################

def check_jxbId(jxbId):
    con = get_create_db(DBFILE)

    try:
        sql = """
            select j.courseId, c.courseName, u.userId, u.userName,
            j.description from JXB j, Course c, UserInfo u
            where j.courseId=c.courseId and j.userId=u.userId and j.jxbId=?;
        """
        executed = con.execute(sql, (jxbId,))
        row = executed.fetchone()  # 结果集的下一行
        if row:return row
        else:return False

    finally:con.close()

def get_jxb_list():
    con = get_create_db(DBFILE)
    try:
        sql = """
            select j.jxbId, j.courseId, c.courseName,j.userId, u.userName, j.description from JXB j, Course c, UserInfo u
            where j.courseId=c.courseId and j.userId=u.userId;
        """
        executed = con.execute(sql)
        jxbs = executed.fetchall()  # 返回结果集剩余行
        jxb_list = []
        for jxb in jxbs:
            jxb_list.append(jxb)
        return jxb_list
    finally:con.close()

def insert_jxb(jxbId, courseId, userId, desc):
    con = get_create_db(DBFILE)
    try:
        sql = """
            insert into JXB(jxbId, courseId, userId, description) values(?,?,?,?)
        """
        con.execute(sql, (jxbId, courseId, userId, desc))
        con.commit()
    except Exception as e:
        print('错误：', e)

    finally:con.close()

def update_jxb(jxbId, courseId, userId, desc):
    con = get_create_db(DBFILE)
    try:
        sql = """
            update JXB set
                courseId=?,
                userId=?,
                description=?
            where jxbId=?
        """
        con.execute(sql, (courseId, userId, desc, jxbId))
        con.commit()
    finally: con.close()

def delete_jxb(jxbId):
    con = get_create_db(DBFILE)
    try:
        sql = """delete from JXB where jxbId=?"""
        con.execute(sql, (jxbId, ))
        con.commit()

    finally: con.close()


##################学生选课###########################

def check_grade_id(jxbId, userId):
    con = get_create_db(DBFILE)
    try:
        sql = """
            select jxbId from Grades where jxbId=? and userId=?
        """
        executed = con.execute(sql, (jxbId, userId))
        row = executed.fetchone()
        if row: return True
        else: return False
    finally:
        con.close()

def get_grade_list_by_student(userId):
    """获取学生选课信息列表"""
    con = get_create_db(DBFILE)
    try:
        sql = """
            select g.jxbId, j.courseId, c.courseName, j.userId,u.userName,j.description, g.score
            from Grades g, JXB j, Course c, UserInfo u
            where g.jxbId=j.jxbId and j.courseId=c.courseId and j.userId=u.userId and g.userId=?;
        """
        executed = con.execute(sql, (userId,))
        grades = executed.fetchall()
        grade_list = []
        for grade in grades:
            grade_list.append(grade)
        return grade_list

    finally: con.close()

def insert_grade(jxbId, userId, score):
    con = get_create_db(DBFILE)
    try:
        sql = """
            insert into Grades(jxbId, userId, score) values(?,?,?)
        """
        con.execute(sql, (jxbId, userId, score))
        con.commit()

    finally:con.close()

def delete_grade(jxbId, userId):
    con = get_create_db(DBFILE)
    try:
        sql ="""
            delete from Grades where jxbId=?
            and userId=?
        """
        con.execute(sql, (jxbId, userId))
        con.commit()

    finally: con.close()

###################教师成绩登录Grades#####################

def get_jxbId_list_user(userId):
    """获取指定教师授课课程信息列表"""
    con = get_create_db(DBFILE)
    try:
        sql = """
            select j.jxbId from JXB j where j.userId=?
        """
        executed = con.execute(sql, (userId,))
        jxbs = [i[0] for i in executed.fetchall()]
        jxbId_dict = {}
        # for jxb in jxbs:
        jxbId_dict[userId] = jxbs
        return jxbId_dict

    finally: con.close()

def get_grade_list_by_jxbId(jxbId):
    """获取指定课程的学生选课信息列表"""
    con = get_create_db(DBFILE)
    try:
        sql = """
            select g.userId, u.userName, u.gender, u.department, g.score from Grades g, UserInfo u
            where g.userId=u.userId
            and g.jxbId=?;
        """
        executed = con.execute(sql, (jxbId,))
        grades = executed.fetchall()
        grade_list = []
        for grade in grades:
            grade_list.append(grade)
        return grade_list
    finally: con.close()

def update_grade_score(grades_list):
    con = get_create_db(DBFILE)
    try:
        sql = """
            update Grades set
            score=? 
            where jxbId=? and userId=?;
        """
        for grade in grades_list:
            con.execute(sql, grade)
        con.commit()
    finally: con.close()


if __name__ == '__main__':
    # get_create_db(DBFILE)
    # change_passwd('J001', 'abcd')
    # print(check_login('2017406202', 'abcd', 2))
    # check_userId('J001')
    # get_user_list("学生")
    # get_user_list("教务")

    # insert_user("学生", "2017406203", "李杰峰", "男", "1998/9/8", "数学系", "18897779580")
    # update_user("2017406203", "黎杰峰","男", "1998/9/8", "数学系", "19994574236")
    # check_courseId("234")

    # insert_course("c1001", "马克思主义基本原理", 2, "公共课必修")
    # insert_jxb("j1001", "c1001", "2017406203", "优质生")
    # insert_grade("j1001", "2017406203", 95)

    # print(get_user_list("学生"))
    # print('----------------------------')

    # print(get_grade_list_by_jxbId('j1001'))
    # print('----------------------------')
    #
    # print(get_grade_list_by_student('2017406202'))
    # print('----------------------------')
    #
    # print(get_jxb_list())
    # print('----------------------------')
    #
    # print(get_jxbId_list_user('2017406202'))

    # print(check_login('2017406202', '123456', '学生'))
    # print(change_passwd('2017406202', 'abcd'))
    # print(check_userId('J001'))
    # print(get_user_list())
    # insert_user('教师', 't1001','宋弈', '男', '1978/3/4', '数学系', '17797776783')
    # update_user()
    # print(check_courseId('c1001'))
    # print(get_course_list())
    # insert_course('c1002', '大学计算机基础', 2, '公共课必修')
    # update_course('c1001', '中国近代史纲要', 2, '公共课必修')
    # print(check_jxbId('j1001'))
    # update_jxb('j1001', 'c1001', 't1001', '32课时数')
    # print(get_jxb_list())
    # insert_jxb('jx1001', 'c1002', 't1002', '16课时')
    # print(check_grade_id('jx1001', '2017406203'))
    # print(get_grade_list_by_student('2017406203'))
    # insert_grade('jx1001', '2017406202', 100)
    print(get_jxbId_list_user('t1002'))

    # print(get_grade_list_by_jxbId('jx1001'))
    # pass