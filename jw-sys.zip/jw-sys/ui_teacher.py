# -*- coding:utf-8 -*-
# @time: 2020/1/13 22:47
# @author: jeremyCheng

import wx, data
import wx.lib.mixins.listctrl as listmix

class EditableListCtrl(wx.ListCtrl, listmix.TextEditMixin):
    def __init__(self, parent, ID=wx.ID_ANY, pos=wx.DefaultPosition, size=wx.DefaultSize, style=0):
        """结构"""
        wx.ListCtrl.__init__(self, parent, ID, pos, size, style)
        listmix.TextEditMixin.__init__(self)
        self.__canEditList = [] # 可编辑项目列表

    def OpenEditor(self, col, row):
        """控制当前项目是否能编辑"""
        if col == 4: #第三列可编辑
            listmix.TextEditMixin.OpenEditor(self, col, row)
        else: pass


import data


class TeacherWindow(wx.Dialog):
    def __init__(self, parent, title, userId):
        wx.Frame.__init__(self, parent, title=title, size=(800, 600))
        self.userId = userId
        panel = wx.Panel(self, wx.ID_ANY)

        # 创建控件
        self.listGrade = EditableListCtrl(panel, wx.ID_ANY, size=(600, 400), style=wx.LC_REPORT | wx.LC_HRULES | wx.LC_VRULES)

        self.listGrade.InsertColumn(0, '学生学号', width=100)
        self.listGrade.InsertColumn(1, '学生姓名', width=150)
        self.listGrade.InsertColumn(2, '性别', width=100)
        self.listGrade.InsertColumn(3, '所在院系', width=150)
        self.listGrade.InsertColumn(6, '成绩', width=100)

        labelJxbId = wx.StaticText(panel, wx.ID_ANY, '教学班号:')
        # self.inputJxbId = wx.TextCtrl(panel, wx.ID_ANY, '', style=wx.TE_PROCESS_ENTER)
        self.comBoxJxbId = wx.ComboBox(panel, wx.ID_ANY, style=wx.CB_READONLY)

        labelCoursID = wx.StaticText(panel, wx.ID_ANY, '课程:')
        self.inputCourseID = wx.TextCtrl(panel, wx.ID_ANY, '', size=(50, 25))
        self.inputCourseID.Disable()

        # labelCourseName = wx.StaticText(panel, wx.ID_ANY, '课程ID：')
        self.inputCourseName = wx.TextCtrl(panel, wx.ID_ANY, '')
        self.inputCourseName.Disable()


        labelDesc = wx.StaticText(panel, wx.ID_ANY, '时间地点:')
        self.inputDesc = wx.TextCtrl(panel, wx.ID_ANY, '')
        self.inputDesc.Disable()

        self.updateBtn = wx.Button(panel, wx.ID_ANY, '成绩登录')

        exitBtn = wx.Button(panel, wx.ID_ANY, '退出')

        topSizer = wx.BoxSizer(wx.VERTICAL)
        editSizer = wx.BoxSizer(wx.HORIZONTAL)
        listSizer = wx.BoxSizer(wx.HORIZONTAL)
        btnSizer = wx.BoxSizer(wx.HORIZONTAL)
        listSizer.Add(self.listGrade, 0, wx.ALL, 5)

        editSizer.Add(labelJxbId,0,wx.ALL, 5)
        editSizer.Add(self.comBoxJxbId,0,wx.ALL, 5)
        editSizer.Add(labelCoursID,0,wx.ALL, 5)
        editSizer.Add(self.inputCourseID,0,wx.ALL, 5)
        editSizer.Add(self.inputCourseName,0,wx.ALL, 5)
        editSizer.Add(labelDesc,0,wx.ALL, 5)
        editSizer.Add(self.inputDesc,0,wx.ALL, 5)

        btnSizer.Add(self.updateBtn,0,wx.ALL, 5)
        btnSizer.Add(exitBtn,0,wx.ALL, 5)



        topSizer.Add(editSizer, 0, wx.ALL | wx.CENTER, 5)
        topSizer.Add(listSizer, 0, wx.ALL | wx.CENTER, 5)
        topSizer.Add(btnSizer, 0, wx.ALL | wx.CENTER, 5)

        panel.SetSizer(topSizer)
        topSizer.Fit(self)

        self.Bind(wx.EVT_COMBOBOX, self.onJxbId, self.comBoxJxbId)

        self.Bind(wx.EVT_BUTTON, self.onUpdate, self.updateBtn)
        self.Bind(wx.EVT_BUTTON, self.onExit, exitBtn)

        # 查询用户信息并显示
        jxbId_list = data.get_jxbId_list_user(self.userId)
        self.comBoxJxbId.Set(jxbId_list[self.userId])

    def populate_grade_list(self):

        jxbId = self.comBoxJxbId.GetValue()
        grade_list = data.get_grade_list_by_jxbId(jxbId)
        self.listGrade.DeleteAllItems()
        index = 0
        for grade in grade_list:
            self.listGrade.InsertItem(index, grade[0])
            self.listGrade.SetItem(index, 1, grade[1])
            self.listGrade.SetItem(index, 2, grade[2])
            self.listGrade.SetItem(index, 3, grade[3])
            if grade[4] == None: self.listGrade.SetItem(index, 4, "")
            else: self.listGrade.SetItem(index, 4, str(grade[4]))
            index += 1

    def onAction(self, e):
        action = self.rboxAction.GetStringSelection()
        if action == '选课':
            self.inputJxbId.Enable()
            self.insertBtn.Enable()
            self.deleteBtn.Disable()

        elif action == '退选':
            self.inputJxbId.Disable()
            self.insertBtn.Disable()
            self.deleteBtn.Enable()

    # def onGradeList(self, e):
    #     '''在列表中选择courses，内容显示在右边'''
    #     index = e.GetIndex()
    #     self.inputJxbId.SetValue(self.listGrade.GetItem(index, 0).GetText())
    #     self.inputCourseID.SetValue(self.listGrade.GetItem(index, 1).GetText())
    #     self.inputCourseName.SetValue(self.listGrade.GetItem(index, 2).GetText())
    #     self.inputUserId.SetValue(self.listGrade.GetItem(index, 3).GetText())
    #     self.inputUserName.SetValue(self.listGrade.GetItem(index, 4).GetText())
    #     self.inputDesc.SetValue(self.listGrade.GetItem(index, 5).GetText())
    #     self.inputScore.SetValue(self.listGrade.GetItem(index, 6).GetText())

    def onJxbId(self, e):
        """插入一条数据"""
        jxbId = self.comBoxJxbId.GetValue()

        if data.check_jxbId(jxbId):
            courseId, couserName, userId, username, desc = data.check_jxbId(jxbId)
            self.inputCourseID.SetValue(courseId)
            self.inputCourseName.SetValue(couserName)
            self.inputDesc.SetValue(desc)

            self.populate_grade_list() #显示所有选课学生信息
        else:
            wx.MessageBox("该课程plan不存在！")
            self.inputCourseID.SetFocus()
            return None

    #
    # def onUserId(self):
    #     userId = self.inputUserId.GetValue()
    #     if len(userId.strip()) == 0:
    #         return None
    #     username = data.check_userId(userId)
    #     if username:
    #         self.inputUserName.SetValue(username)
    #     else:
    #         wx.MessageBox("该教师不存在！")
    #         self.inputUserId.SetFocus()
    #         return None

    def onUpdate(self, e):

        jxbid = self.comBoxJxbId.GetValue()
        courseId = self.inputCourseID.GetValue()
        desc = self.inputDesc.GetValue()

        if len(jxbid.strip()) == 0:
            wx.MessageBox("请选择教学班号登录成绩！")
            self.comBoxJxbId.SetFocus()
            return None

        grades_list = []
        for index in range(self.listGrade.GetItemCount()):
            userid = self.listGrade.GetItem(index, 0).GetText()
            try:
                score = int(self.listGrade.GetItem(index, 4).GetText())
            except:
                score = 0

            grades_list.append([score, jxbid, userid])
            data.update_grade_score(grades_list)
            wx.MessageBox("成绩登录成功！")


    def onExit(self, e):
        self.Close(True)

