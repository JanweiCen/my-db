# -*- coding:utf-8 -*-
#@time: 2019/12/31 15:44
#@author: jeremyCheng

import wx
import ui_login
import ui_change_passwd
import ui_user
import ui_course
import ui_jxb
import ui_student
import ui_teacher

class MainWindow(wx.Frame):
    def __init__(self, parent, title, userId, username, userType):
        wx.Frame.__init__(self, parent, title=title, size=(640, 480))
        self.CreateStatusBar() # 状态栏
        self.userId = userId
        self.username = username
        self.userType = userType

        # 创建菜单
        sys_menu = wx.Menu() # 系统菜单：登录，改密，退出
        jw_menu = wx.Menu() # 教务菜单：用户管理，课程管理，开课管理
        stu_menu = wx.Menu() # 系统菜单：选课，查成绩
        tea_menu = wx.Menu() # 系统菜单：录入成绩
        help_menu = wx.Menu() # 帮助菜单

        # 以下使用的是标准菜单ID
        menuLogin = sys_menu.Append(wx.ID_ANY, '重新登录', '重新登录')
        menuChangPasswd = sys_menu.Append(wx.ID_ANY, '修改密码', '修改密码')
        menuExit = sys_menu.Append(wx.ID_EXIT, '退出系统', '退出')
        menuUser = jw_menu.Append(wx.ID_ANY, '用户管理','用户管理')
        menuCourse = jw_menu.Append(wx.ID_ANY, '课程管理','课程管理')
        menuJXB = jw_menu.Append(wx.ID_ANY, '开课计划','开课计划')
        menuTeacher = tea_menu.Append(wx.ID_ANY, '成绩录入', '成绩录入')
        menuStudent = stu_menu.Append(wx.ID_ANY, '学生选课','学生选课')
        menuAbout = help_menu.Append(wx.ID_ABOUT, '关于', '关于')

        # 创建菜单栏。根据身份显示不同菜单
        menuBar = wx.MenuBar()
        menuBar.Append(sys_menu, '系统') # 把菜单添加到菜单栏
        if self.userType == 0:
            menuBar.Append(jw_menu, '教务')
        elif self.userType == 1:
            menuBar.Append(tea_menu, '教师')
        elif self.userType == 2:
            menuBar.Append(stu_menu, '学生')

        menuBar.Append(help_menu, '关于')

        self.SetMenuBar(menuBar) # 把菜单栏添加到顶层窗口

        self.Bind(wx.EVT_MENU, self.OnLogin, menuLogin)
        self.Bind(wx.EVT_MENU, self.OnChangePasswd, menuChangPasswd)
        self.Bind(wx.EVT_MENU, self.OnExit, menuExit)
        self.Bind(wx.EVT_MENU, self.OnUser, menuUser)
        self.Bind(wx.EVT_MENU, self.OnCourse, menuCourse)
        self.Bind(wx.EVT_MENU, self.OnJXB, menuJXB)
        self.Bind(wx.EVT_MENU, self.OnStudent, menuStudent)
        self.Bind(wx.EVT_MENU, self.OnTeacher, menuTeacher)
        self.Bind(wx.EVT_MENU, self.OnAbout, menuAbout)

    # 事件处理函数
    def OnAbout(self, e):
        dlg = wx.MessageDialog(self, "简易教务管理系统v1.0\nby JeremyCheng", "简易教务管理系统", wx.OK)
        dlg.ShowModal() # 显示模式对话框
        dlg.Destroy() # 销毁对话框

    def OnExit(self, e):
        self.Close(True)

    def OnLogin(self, e):
        '''重新登录'''
        self.Close(True)
        loginFrame = ui_login.LoginWindow(parent=None, title="重新登录")
        loginFrame.Show()
        loginFrame.Center()

    def OnChangePasswd(self, e):
        changepwdFrame = ui_change_passwd.ChangePasswdWindow(parent=None, title="修改密码")
        changepwdFrame.Show()
        changepwdFrame.Center()
        changepwdFrame.userId = self.userId

    def OnUser(self, e):
        """用户管理"""
        userFrame = ui_user.UserWindow(parent=None, title="用户管理")
        userFrame.Show()
        userFrame.Center()

    def OnCourse(self, e):
        """课程管理"""
        courseFrame = ui_course.CourseWindow(parent=None, title="课程管理")
        courseFrame.Show()
        courseFrame.Center()

    def OnJXB(self, e):
        jxbFrame = ui_jxb.JXBWindow(parent=None, title="开课计划")
        jxbFrame.Show()
        jxbFrame.Center()

    def OnStudent(self, e):
        stuFrame = ui_student.StudentWindow(parent=None, title="学生选课", userId=self.userId)
        stuFrame.Show()
        stuFrame.Center()

    def OnTeacher(self, e):
        teaFrame = ui_teacher.TeacherWindow(parent=None, title="教师登录成绩", userId=self.userId)
        teaFrame.Show()
        teaFrame.Center()

